import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import java.security.KeyFactory
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

Message processData(Message message) {

    def props = message.getProperties()
    def fileName = (props.get('FileName') ?: 'upload.bin') as String
    def mimeType = (props.get('MimeType') ?: 'application/octet-stream') as String
    def folderId = props.get('GDRIVE_FOLDER_ID') as String   // paramètre externalisé
    byte[] fileContent = message.getBody(byte[].class)

    // ---- 1. Credentials du service account (Security Material "User Credentials" nommé GDRIVE_SA)
    //         username = client_email, password = clé privée PEM (une seule ligne, \n conservés)
    SecureStoreService secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
    UserCredential cred = secureStoreService.getUserCredential("GDRIVE_SA")
    String clientEmail = cred.getUsername()
    String privateKeyPem = new String(cred.getPassword())
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replaceAll("\\s", "")

    // ---- 2. Construction et signature du JWT (RS256)
    long nowSec = System.currentTimeMillis() / 1000L
    def header = JsonOutput.toJson([alg: "RS256", typ: "JWT"])
    def claims = JsonOutput.toJson([
            iss  : clientEmail,
            scope: "https://www.googleapis.com/auth/drive.file",
            aud  : "https://oauth2.googleapis.com/token",
            iat  : nowSec,
            exp  : nowSec + 3600
    ])
    def b64 = { String s -> Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes("UTF-8")) }
    String unsigned = "${b64(header)}.${b64(claims)}"

    byte[] keyBytes = Base64.getDecoder().decode(privateKeyPem)
    def privateKey = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyBytes))
    Signature signer = Signature.getInstance("SHA256withRSA")
    signer.initSign(privateKey)
    signer.update(unsigned.getBytes("UTF-8"))
    String signature = Base64.getUrlEncoder().withoutPadding().encodeToString(signer.sign())
    String jwt = "${unsigned}.${signature}"

    // ---- 3. Echange du JWT contre un access_token
    String tokenBody = "grant_type=" + URLEncoder.encode("urn:ietf:params:oauth:grant-type:jwt-bearer", "UTF-8") +
                        "&assertion=" + URLEncoder.encode(jwt, "UTF-8")
    def tokenConn = new URL("https://oauth2.googleapis.com/token").openConnection()
    tokenConn.setRequestMethod("POST")
    tokenConn.setDoOutput(true)
    tokenConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
    tokenConn.outputStream.withWriter("UTF-8") { it << tokenBody }
    def tokenResponse = new JsonSlurper().parse(tokenConn.inputStream)
    String accessToken = tokenResponse.access_token

    // ---- 4. Construction du corps multipart/related pour l'upload Drive
    def metadata = [name: fileName]
    if (folderId) metadata.parents = [folderId]
    String boundary = "cpi_boundary_" + System.currentTimeMillis()
    def out = new ByteArrayOutputStream()
    out << "--${boundary}\r\n"
    out << "Content-Type: application/json; charset=UTF-8\r\n\r\n"
    out << JsonOutput.toJson(metadata)
    out << "\r\n--${boundary}\r\n"
    out << "Content-Type: ${mimeType}\r\n\r\n"
    out.write(fileContent)
    out << "\r\n--${boundary}--"

    // ---- 5. Appel Google Drive API
    def driveConn = new URL("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart").openConnection()
    driveConn.setRequestMethod("POST")
    driveConn.setDoOutput(true)
    driveConn.setRequestProperty("Authorization", "Bearer ${accessToken}")
    driveConn.setRequestProperty("Content-Type", "multipart/related; boundary=${boundary}")
    driveConn.outputStream.write(out.toByteArray())

    int status = driveConn.responseCode
    def responseStream = status < 400 ? driveConn.inputStream : driveConn.errorStream
    String driveResponse = responseStream.getText("UTF-8")

    message.setHeader("GDriveHttpStatus", status as String)
    message.setBody(driveResponse)
    return message
}
